# Cara Menjalankan Program
1. Cari direktori penyimpanan file `main.py`, buka terminal dari direktori tersebut
2. Tulis `python3 main.py` pada terminal, lalu enter
3. Tuliskan alamat input teks